<?php
/**
 * AIFO Status Controller for HopeBilling
 * Контролер статусу AIFO для HopeBilling
 * 
 * @package    AIFO
 * @author     AIFO.PRO
 * @copyright  Copyright (c) 2026 AIFO.PRO
 * @license    Proprietary
 */

namespace modules\aifo\controllers\front;

use front\ModuleFrontController;
use model\Bill;
use model\Client;
use model\Currency;
use modules\aifo\classes\payment\AIFOAPI;
use System\Config;
use System\Notifier;

class AIFOStatusController extends ModuleFrontController{
    protected $auth = false;
    public function actionStatus(){
        $pconfig = new Config('payments');
        $aifo =  new AIFOAPI(array(
            'shop_id'       => $pconfig->aifo->shop_id,
            'secret_key'   => $pconfig->aifo->secret_key,
            'signature_type' => $pconfig->aifo->signature_type,
            'aifo_url'      => $pconfig->aifo->aifo_url
        ));

        $payment = $aifo->getPayment();
        if ($payment->verified) {
            $bill = new Bill($payment->getId());
            if ($bill->isLoadedObject() &&  $bill->total == $payment->getAmount()) {
                $bill->pay();
                $Client = new Client($bill->client_id);
                Notifier::PaidBill($Client, $bill);
                exit('OK');
            }
        }
        exit('ERROR');
    }
}

