<form method="post">
    <fieldset>
        <div class="form-group">
            <label><?=$_->l('ID магазину')?></label>
            <input type="text" id="disabledTextInput" name="shop_id"
                   value="<?= isset($pconfig->aifo->shop_id) ? $pconfig->aifo->shop_id : '' ?>"
                   class="form-control" placeholder="<?=$_->l('ID магазину')?>">
        </div>
        <div class="form-group">
            <label><?=$_->l('Секретний ключ')?></label>
            <input type="password" id="disabledTextInput" name="secret_key"
                   value="<?= isset($pconfig->aifo->secret_key) ? $pconfig->aifo->secret_key : '' ?>"
                   class="form-control"
                   placeholder="<?=$_->l('Секретний ключ')?>">
        </div>
        <div class="form-group">
            <label><?=$_->l('Тип підпису')?></label>
            <select name="signature_type" class="form-control">
                <option value="1" <?= (isset($pconfig->aifo->signature_type) && $pconfig->aifo->signature_type == 1) ? 'selected' : '' ?>>MD5</option>
                <option value="2" <?= (isset($pconfig->aifo->signature_type) && $pconfig->aifo->signature_type == 2) ? 'selected' : '' ?>>SHA256</option>
                <option value="3" <?= (isset($pconfig->aifo->signature_type) && $pconfig->aifo->signature_type == 3) ? 'selected' : '' ?>>SHA1</option>
                <option value="4" <?= (isset($pconfig->aifo->signature_type) && $pconfig->aifo->signature_type == 4) ? 'selected' : '' ?>>RIPEMD160</option>
                <option value="5" <?= (isset($pconfig->aifo->signature_type) && $pconfig->aifo->signature_type == 5) ? 'selected' : '' ?>>SHA384</option>
                <option value="6" <?= (isset($pconfig->aifo->signature_type) && $pconfig->aifo->signature_type == 6) ? 'selected' : '' ?>>SHA512</option>
            </select>
        </div>
        <div class="form-group">
            <label><?=$_->l('URL сервісу AIFO')?></label>
            <input type="text" id="disabledTextInput" name="aifo_url"
                   value="<?= isset($pconfig->aifo->aifo_url) ? $pconfig->aifo->aifo_url : 'https://aifo.pro' ?>"
                   class="form-control"
                   placeholder="<?=$_->l('URL сервісу AIFO')?>">
        </div>
        <button type="submit" class="btn btn-primary"><?= $_->l('Зберегти') ?></button>
    </fieldset>
</form>

