
<? if (isset($aifo)) { ?>
    <form action="<?= $aifo->getFormAction(); ?>" method="get">
        <?php foreach ($aifo->getFormValues() as $field => $value): ?>
            <input type="hidden" name="<?= $field; ?>" value="<?= $value; ?>"/>
        <?php endforeach; ?>
        <button type="submit" class="payment_button"
                style="background: url(<?= $_->link('app/modules/aifo/template/front/default/img/aifo.png') ?>) no-repeat center;"></button>
    </form>
<? } ?>

