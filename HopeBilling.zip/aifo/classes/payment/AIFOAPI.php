<?php
/**
 * AIFO Payment API Class for HopeBilling
 * Клас API оплати AIFO для HopeBilling
 * 
 * @package    AIFO
 * @author     AIFO.PRO
 * @copyright  Copyright (c) 2026 AIFO.PRO
 * @license    Proprietary
 */

namespace modules\aifo\classes\payment;

use payment\PaymentAPI;
use System\Exception;
use System\Logger;

class AIFOAPI extends PaymentAPI
{
    protected $aifo_url = 'https://aifo.pro';
    protected $signature_type = 1; // 1=md5, 2=sha256, 3=sha1, 4=ripemd160, 5=sha384, 6=sha512
    
    public function __construct($shop = array())
    {
        parent::__construct($shop);
        if (isset($shop['aifo_url']) && !empty($shop['aifo_url'])) {
            $this->aifo_url = rtrim($shop['aifo_url'], '/');
        }
        if (isset($shop['signature_type'])) {
            $this->signature_type = (int)$shop['signature_type'];
        }
    }
    
    public function setFormAction(){
        $this->_form_action = $this->aifo_url . '/pay/';
    }

    public function getFormValues()
    {
        $fields            = $this->getFields();
        $fields['sign']    = $this->getSign($fields);
        return $fields;
    }

    public function getFields()
    {
        $fields = [
            'shop_id'         => $this->_shop['shop_id'],
            'amount'        => $this->getAmountAsString(),
            'id'         => $this->getId() // Используем id согласно API
        ];
        return $fields;
    }

    public function getSign($fields)
    {
        $sign = '';
        if ($this->signature_type == 1) {
            $sign = md5($fields['shop_id'].':'.$this->getAmountAsString().':'.$this->_shop['secret_key'].':'.$fields['id']);
        } elseif ($this->signature_type == 2) {
            $sign = hash('sha256', $fields['shop_id'].':'.$this->getAmountAsString().':'.$this->_shop['secret_key'].':'.$fields['id']);
        } elseif ($this->signature_type == 3) {
            $sign = hash('sha1', $fields['shop_id'].':'.$this->getAmountAsString().':'.$this->_shop['secret_key'].':'.$fields['id']);
        } elseif ($this->signature_type == 4) {
            $sign = hash('ripemd160', $fields['shop_id'].':'.$this->getAmountAsString().':'.$this->_shop['secret_key'].':'.$fields['id']);
        } elseif ($this->signature_type == 5) {
            $sign = hash('sha384', $fields['shop_id'].':'.$this->getAmountAsString().':'.$this->_shop['secret_key'].':'.$fields['id']);
        } elseif ($this->signature_type == 6) {
            $sign = hash('sha512', $fields['shop_id'].':'.$this->getAmountAsString().':'.$this->_shop['secret_key'].':'.$fields['id']);
        } else {
            $sign = md5($fields['shop_id'].':'.$this->getAmountAsString().':'.$this->_shop['secret_key'].':'.$fields['id']);
        }
        return $sign;
    }
	
	final protected function _checkSignature(array $source)
    {
        Logger::log('AIFO signature argument: '.$this->_shop['shop_id'].':'.$source['sum'].':'.$this->_shop['secret_key'].':'.$source['invoice']);
        Logger::log(json_encode($source));
        
        $sign = '';
        if ($this->signature_type == 1) {
            $sign = md5($this->_shop['shop_id'].':'.$source['sum'].':'.html_entity_decode($this->_shop['secret_key']).':'.$source['invoice']);
        } elseif ($this->signature_type == 2) {
            $sign = hash('sha256', $this->_shop['shop_id'].':'.$source['sum'].':'.html_entity_decode($this->_shop['secret_key']).':'.$source['invoice']);
        } elseif ($this->signature_type == 3) {
            $sign = hash('sha1', $this->_shop['shop_id'].':'.$source['sum'].':'.html_entity_decode($this->_shop['secret_key']).':'.$source['invoice']);
        } elseif ($this->signature_type == 4) {
            $sign = hash('ripemd160', $this->_shop['shop_id'].':'.$source['sum'].':'.html_entity_decode($this->_shop['secret_key']).':'.$source['invoice']);
        } elseif ($this->signature_type == 5) {
            $sign = hash('sha384', $this->_shop['shop_id'].':'.$source['sum'].':'.html_entity_decode($this->_shop['secret_key']).':'.$source['invoice']);
        } elseif ($this->signature_type == 6) {
            $sign = hash('sha512', $this->_shop['shop_id'].':'.$source['sum'].':'.html_entity_decode($this->_shop['secret_key']).':'.$source['invoice']);
        } else {
            $sign = md5($this->_shop['shop_id'].':'.$source['sum'].':'.html_entity_decode($this->_shop['secret_key']).':'.$source['invoice']);
        }
        
        if ((string)$sign === (string)$source['http_auth_signature']) {
            return true;
        }
        return false;
    }

    final protected function _checkIp(){
        if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) return $_SERVER['HTTP_CF_CONNECTING_IP'];
		if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) return $_SERVER['HTTP_X_FORWARDED_FOR'];
		if (isset($_SERVER['HTTP_X_REAL_IP'])) return $_SERVER['HTTP_X_REAL_IP'];
		return $_SERVER['REMOTE_ADDR'];
    }

    public function getPayment()
    {
        $source = $_REQUEST;
        if (!$source || empty($source)) {
            throw new Exception('Source not exist');
        }

        // Проверка IP (если настроена)
        if (isset($this->_shop['ip_filter']) && !empty($this->_shop['ip_filter'])) {
            $allowedIPs = explode(',', str_replace(' ', '', $this->_shop['ip_filter']));
            $clientIP = $this->_checkIp();
            if (!in_array($clientIP, $allowedIPs)) {
                die("hacking attempt!");
            }
        }

        if ($this->_checkSignature($source)) {
            $this->verified = true;
        } else {
            throw new Exception('error signature');
        }

        $this->_id          = $source['invoice'];
        $this->_amount      = $source['sum'];
        return $this;
    }
}

