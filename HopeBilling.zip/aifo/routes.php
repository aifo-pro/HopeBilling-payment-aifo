<?php
return array(
    'status' => 'front|AIFOStatus|status',
    'result' => 'front|AIFO|result'
);

