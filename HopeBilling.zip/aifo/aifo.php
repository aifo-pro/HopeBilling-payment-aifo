<?php
/**
 * AIFO Payment Module for HopeBilling
 * Модуль оплати AIFO для HopeBilling
 * 
 * @package    AIFO
 * @author     AIFO.PRO
 * @copyright  Copyright (c) 2026 AIFO.PRO
 * @license    Proprietary
 */

namespace modules\aifo;

use modules\aifo\classes\payment\AIFOAPI;
use model\Bill;
use model\Currency;
use stdClass;
use System\Config;
use System\Module;
use System\Router;
use System\Tools;

class aifo extends Module{
    public $name = 'Платіжна система AIFO';
    public $author = '<a target="_blank" href="https://aifo.pro">AIFO.PRO</a>';
    public $category = 3; // for payments systems

    public function install()
    {
        $pconfig                                 = new Config('payments');
        $pconfig->aifo                      = new stdClass();
        $pconfig->aifo->enable              = 0;
        $pconfig->aifo->shop_id             = "";
        $pconfig->aifo->secret_key         = "";
        $pconfig->aifo->signature_type     = 1; // 1=md5, 2=sha256, 3=sha1, 4=ripemd160, 5=sha384, 6=sha512
        $pconfig->aifo->aifo_url           = "https://aifo.pro";
        $pconfig->save();
        $this->registerHook('displayPaymentMethods');
    }

    public function uninstall()
    {
        $pconfig = new Config('payments');
        $pconfig->delete('aifo');
        $pconfig->save();
        return parent::uninstall();
    }

    public function displayPaymentMethods(&$view)
    {
        $pconfig = new Config('payments');
        $id_bill = Router::getParam(0);
        $Bill = new Bill($id_bill);
        $view = $this->getModuleView('bill/pay.php');
        $dcurrency = new Currency($this->config->currency_default);
        
        // AIFO
        $aifo = new AIFOAPI(array(
            'shop_id'       => $pconfig->aifo->shop_id,
            'secret_key'    => $pconfig->aifo->secret_key,
            'signature_type' => $pconfig->aifo->signature_type,
            'aifo_url'      => $pconfig->aifo->aifo_url
        ));

        $payment          = $aifo->createPayment(array(
            'id'          => $Bill->id,
            'amount'      => $Bill->total,
            'description' => 'Оплата послуг компанії',
            'currency'    => $dcurrency->iso
        ));

        $view->aifo = $payment;
        // AIFO end

        $view->id_bill = $id_bill;
    }

    public function actionSetting(){
        $pconfig = new Config('payments');
        if (Tools::rPOST()) {
            $pconfig->aifo->shop_id       = Tools::rPOST('shop_id');
            $pconfig->aifo->secret_key    = Tools::rPOST('secret_key');
            $pconfig->aifo->signature_type = (int)Tools::rPOST('signature_type');
            $pconfig->aifo->aifo_url      = Tools::rPOST('aifo_url');
            $pconfig->save();
        }

        $view  = $this->getModuleView('setting.php', 'admin');
        $view->pconfig= $pconfig;
        $view->currencies = Currency::factory()->getRows();
        return $view;
    }
}

